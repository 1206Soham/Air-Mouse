# SKYNC Air Mouse – Control Center (Full GUI with Joystick Centers + Auto-Center)
# -------------------------------------------------------------------------------
# - Password gate
# - Per-direction tilt sensitivity, deadzone, smoothing (Up/Down/Right/Left)
# - Max speed clamp
# - Joystick tuning: deadband, X/Y gains, smoothing, rate limit, max lines
# - Per-axis joystick centers (X/Y) + Auto-Center button
# - Re-zero baseline button (sends 'Z' to firmware)
#
# ESP32 firmware must stream CSV lines:
#   roll,pitch,btnL,btnR,joyX,joyY,joyBtn
# -------------------------------------------------------------------------------

import sys, threading, time, math, getpass, collections
from queue import Queue
import serial
from pynput.mouse import Controller, Button
import tkinter as tk
from tkinter import ttk

########### CONFIG ###########
PORT = "COM8"       # <-- change to your ESP32 port
BAUD = 115200
ARM_PASSWORD = "skync"     # <-- change to your fav password
##############################

mouse = Controller()
ser = None
running = True

# --- Defaults based on your measured centers (X≈1930, Y≈1910) ---
JOY_CENTER_X_DEFAULT = 1930
JOY_CENTER_Y_DEFAULT = 1910

params = {
    # Tilt sensitivity (px/deg)
    "gain_up": 2.2, "gain_down": 2.2, "gain_right": 2.2, "gain_left": 2.2,
    # Deadzones (deg)
    "dz_up": 3.0, "dz_down": 3.0, "dz_right": 3.0, "dz_left": 3.0,
    # Smoothing (EMA alpha 0..1)
    "alpha_up": 0.20, "alpha_down": 0.20, "alpha_right": 0.20, "alpha_left": 0.20,
    # Clamp
    "max_speed": 18,

    # Joystick tuning
    "joy_db": 240,           # deadband (ADC units)
    "joy_gain_x": 0.002,     # horizontal scroll factor
    "joy_gain_y": 0.004,     # vertical scroll factor
    "joy_alpha": 0.25,       # joystick EMA smoothing (0..1)
    "joy_max_step": 2,       # max lines per dispatch per axis
    "joy_rate_hz": 50,       # max scroll dispatches per second

    # Per-axis joystick centers (editable via GUI)
    "joy_center_x": JOY_CENTER_X_DEFAULT,
    "joy_center_y": JOY_CENTER_Y_DEFAULT,
}

# Smoothed/prev state + short history for auto-center
state = {
    "f_roll_up": 0.0, "f_roll_dn": 0.0, "f_pitch_rt": 0.0, "f_pitch_lt": 0.0,
    "prevL": 0, "prevR": 0, "prevM": 0,
    "f_jx": 0.0, "f_jy": 0.0,
    "scroll_acc_x": 0.0, "scroll_acc_y": 0.0, "last_scroll_ts": 0.0,
    # history buffers (recent joystick raw values)
    "hist_jx": collections.deque(maxlen=200),
    "hist_jy": collections.deque(maxlen=200),
}

def apply_ema(v, s, a):
    a = max(0.0, min(1.0, float(a)))
    return a*v + (1.0 - a)*s

def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v

def dz(v, d):
    d = max(0.0, float(d))
    return 0.0 if abs(v) <= d else (v - (d if v > 0 else -d))

# ---------------- Serial Reader ----------------
def serial_reader(q):
    global ser, running
    try:
        ser = serial.Serial(PORT, BAUD, timeout=1)
    except Exception as e:
        print(f"[Serial] Error opening port {PORT}: {e}")
        running = False
        return

    # Drain banner/headers
    time.sleep(1)

    while running:
        try:
            line = ser.readline().decode(errors="ignore").strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(",")
            if len(parts) != 7:
                continue
            roll  = float(parts[0])      # +X tilt
            pitch = float(parts[1])      # +Y tilt
            btnL  = int(parts[2])
            btnR  = int(parts[3])
            jx    = int(parts[4])        # 0..4095
            jy    = int(parts[5])        # 0..4095
            jbtn  = int(parts[6])        # 0/1
            q.put((roll, pitch, btnL, btnR, jx, jy, jbtn))
        except Exception:
            pass

    try:
        ser.close()
    except:
        pass

def rezero_baseline():
    if ser and ser.is_open:
        try:
            ser.write(b"Z\n")
        except:
            pass

# ---------------- Control Loop ----------------
def control_loop(q):
    while running:
        try:
            roll, pitch, btnL, btnR, jx, jy, jbtn = q.get(timeout=0.1)
        except:
            continue

        # Keep a short history for auto-center
        state["hist_jx"].append(jx)
        state["hist_jy"].append(jy)

        # ----- Tilt → cursor -----
        if roll >= 0:
            state["f_roll_up"] = apply_ema(roll, state["f_roll_up"], params["alpha_up"])
            dy = int(-dz(state["f_roll_up"], params["dz_up"]) * params["gain_up"])   # +roll => UP (negative dy)
        else:
            r = -roll
            state["f_roll_dn"] = apply_ema(r, state["f_roll_dn"], params["alpha_down"])
            dy = int(dz(state["f_roll_dn"], params["dz_down"]) * params["gain_down"])  # -roll => DOWN (+dy)

        if pitch >= 0:
            state["f_pitch_rt"] = apply_ema(pitch, state["f_pitch_rt"], params["alpha_right"])
            dx = int(dz(state["f_pitch_rt"], params["dz_right"]) * params["gain_right"])  # +pitch => RIGHT (+dx)
        else:
            p = -pitch
            state["f_pitch_lt"] = apply_ema(p, state["f_pitch_lt"], params["alpha_left"])
            dx = int(-dz(state["f_pitch_lt"], params["dz_left"]) * params["gain_left"])   # -pitch => LEFT (-dx)

        ms = int(params["max_speed"])
        dx, dy = clamp(dx, -ms, ms), clamp(dy, -ms, ms)
        if dx or dy:
            mouse.move(dx, dy)

        # ----- Buttons -----
        if btnL != state["prevL"]:
            mouse.press(Button.left) if btnL else mouse.release(Button.left)
            state["prevL"] = btnL
        if btnR != state["prevR"]:
            mouse.press(Button.right) if btnR else mouse.release(Button.right)
            state["prevR"] = btnR

        # ----- Joystick → scroll (smoothed + deadband + rate-limited) -----
        # Offset with per-axis centers
        jdx = jx - float(params["joy_center_x"])
        jdy = jy - float(params["joy_center_y"])

        # EMA smoothing
        a = float(params["joy_alpha"])
        state["f_jx"] = apply_ema(jdx, state["f_jx"], a)
        state["f_jy"] = apply_ema(jdy, state["f_jy"], a)

        # Deadband
        def deadband(v, d):
            return 0.0 if abs(v) <= d else (v - (d if v > 0 else -d))

        jx_u = deadband(state["f_jx"], params["joy_db"])
        jy_u = deadband(state["f_jy"], params["joy_db"])

        # Convert to fractional "lines"
        gx, gy = float(params["joy_gain_x"]), float(params["joy_gain_y"])
        state["scroll_acc_x"] += jx_u * gx
        state["scroll_acc_y"] += -jy_u * gy    # invert: stick up => scroll up

        # Rate limit
        now = time.time()
        min_dt = 1.0 / max(1.0, float(params["joy_rate_hz"]))
        if (now - state["last_scroll_ts"]) >= min_dt:
            maxs = int(params["joy_max_step"])
            sx = int(clamp(int(state["scroll_acc_x"]), -maxs, maxs))
            sy = int(clamp(int(state["scroll_acc_y"]), -maxs, maxs))
            if sx or sy:
                mouse.scroll(sx, sy)
                state["scroll_acc_x"] -= sx
                state["scroll_acc_y"] -= sy
                state["last_scroll_ts"] = now

        # Joystick switch => middle click
        if jbtn != state["prevM"]:
            mouse.press(Button.middle) if jbtn else mouse.release(Button.middle)
            state["prevM"] = jbtn

# ---------------- GUI ----------------
def build_gui(q_for_autocenter: Queue):
    root = tk.Tk()
    root.title("SKYNC Air Mouse – Control Center")

    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except:
        pass

    def add_slider(row, label, key, frm, to, col=0):
        ttk.Label(root, text=label, width=22, anchor="e").grid(row=row, column=col, sticky="e", padx=6, pady=4)
        scale = ttk.Scale(root, from_=frm, to=to, orient="horizontal",
                          command=lambda v, k=key: params.__setitem__(k, float(v)))
        scale.set(params[key])
        scale.grid(row=row, column=col+1, sticky="ew", padx=6)

    root.columnconfigure(1, weight=1)
    root.columnconfigure(3, weight=1)

    r = 0
    ttk.Label(root, text="Tilt Sensitivity", font=("Segoe UI", 10, "bold")).grid(row=r, column=0, columnspan=4, pady=(8,2)); r += 1
    add_slider(r, "Up (roll +)", "gain_up", 0, 6);              add_slider(r, "Smoothing Up",   "alpha_up",   0, 1, col=2); r += 1
    add_slider(r, "Down (roll −)", "gain_down", 0, 6);          add_slider(r, "Smoothing Down", "alpha_down", 0, 1, col=2); r += 1
    add_slider(r, "Right (pitch +)", "gain_right", 0, 6);       add_slider(r, "Smoothing Right","alpha_right",0, 1, col=2); r += 1
    add_slider(r, "Left (pitch −)", "gain_left", 0, 6);         add_slider(r, "Smoothing Left", "alpha_left", 0, 1, col=2); r += 1

    ttk.Label(root, text="Tilt Deadzones (°)", font=("Segoe UI", 10, "bold")).grid(row=r, column=0, columnspan=4, pady=(10,2)); r += 1
    add_slider(r, "DZ Up", "dz_up", 0, 8);                       add_slider(r, "DZ Down",  "dz_down",  0, 8, col=2); r += 1
    add_slider(r, "DZ Right", "dz_right", 0, 8);                 add_slider(r, "DZ Left",  "dz_left",  0, 8, col=2); r += 1

    ttk.Label(root, text="Other", font=("Segoe UI", 10, "bold")).grid(row=r, column=0, columnspan=4, pady=(10,2)); r += 1
    add_slider(r, "Max Speed (px/frame)", "max_speed", 2, 50); r += 1

    ttk.Label(root, text="Joystick Settings", font=("Segoe UI", 10, "bold")).grid(row=r, column=0, columnspan=4, pady=(10,2)); r += 1
    add_slider(r, "Deadband",       "joy_db",       0, 600);                   add_slider(r, "Joystick Smoothing", "joy_alpha",   0, 1,   col=2); r += 1
    add_slider(r, "Scroll Gain X",  "joy_gain_x",   0.0, 0.05);                add_slider(r, "Scroll Gain Y",      "joy_gain_y",  0.0, 0.05, col=2); r += 1
    add_slider(r, "Rate Limit (Hz)","joy_rate_hz",  10, 120);                  add_slider(r, "Max Lines/Frame",    "joy_max_step",1, 5,   col=2); r += 1
    add_slider(r, "Center X",       "joy_center_x", 0, 4095);                  add_slider(r, "Center Y",           "joy_center_y",0, 4095, col=2); r += 1

    # Auto-Center button averages the recent history (non-blocking)
    def auto_center_joystick():
        xs = list(state["hist_jx"])
        ys = list(state["hist_jy"])
        if xs and ys:
            params["joy_center_x"] = sum(xs) / len(xs)
            params["joy_center_y"] = sum(ys) / len(ys)
            print(f"[Auto-Center] X={params['joy_center_x']:.1f}, Y={params['joy_center_y']:.1f}")

    # Bottom buttons
    btnf = ttk.Frame(root); btnf.grid(row=r, column=0, columnspan=4, pady=10)
    ttk.Button(btnf, text="Re-Zero (Z)", command=rezero_baseline).grid(row=0, column=0, padx=6)
    ttk.Button(btnf, text="Auto-Center Joystick", command=auto_center_joystick).grid(row=0, column=1, padx=6)
    ttk.Button(btnf, text="Exit", command=lambda: root.destroy()).grid(row=0, column=2, padx=6)

    return root

# ---------------- Main ----------------
def main():
    pwd = getpass.getpass("Enter password to arm AirMouse: ")
    if pwd != ARM_PASSWORD:
        print("Auth failed.")
        return

    q = Queue()
    threading.Thread(target=serial_reader, args=(q,), daemon=True).start()
    threading.Thread(target=control_loop, args=(q,), daemon=True).start()

    gui = build_gui(q)
    try:
        gui.mainloop()
    finally:
        global running
        running = False
        time.sleep(0.2)

if __name__ == "__main__":
    main()
